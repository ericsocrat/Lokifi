import React from "react";
export default function ContextMenu(p:{children?:React.ReactNode}){ return <>{p.children}</>; }
